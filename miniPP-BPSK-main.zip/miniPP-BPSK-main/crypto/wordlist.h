const char* getword(short b);

